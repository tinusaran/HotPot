import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Admin } from './admin';
import { Orders } from './orders';
import { Menu } from './menu';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  private baseUrl = 'http://localhost:9090';

  constructor(private http: HttpClient) {}

  // Login as vendor/admin
  loginVendor(vendor: any): Observable<any> {
    return this.http.post<any>(
      this.baseUrl + '/auth/login',
      {
        username: vendor.username,
        password: vendor.password,
      }
    );
  }

  // Add vendor
  addVendor(vendor: any): Observable<string> {
    return this.http.post<string>(this.baseUrl + '/addVendor', vendor, {
      responseType: 'text' as 'json',
    });
  }

  // Get all vendors
  getAllVendors(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl + '/showVendors');
  }

  // Get vendor by username
  getVendorByUsername(username: string): Observable<any> {
    return this.http.get<any>(this.baseUrl + '/searchVendorByUsername/' + username);
  }

  // Get vendor by ID
  getVendorById(venId: number): Observable<any> {
    return this.http.get<any>(this.baseUrl + '/searchVendorById/' + venId);
  }

  // Vendor: get all customers
  getAllCustomers(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl + '/vendor/customers');
  }

  // Vendor: get all restaurants
  getAllRestaurants(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl + '/vendor/restaurants');
  }

  // Vendor: get all orders
  getAllOrders(): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/vendor/orders');
  }

  // Vendor: delete customer
  deleteCustomer(id: number): Observable<string> {
    return this.http.delete<string>(this.baseUrl + '/vendor/customer/' + id, {
      responseType: 'text' as 'json',
    });
  }

  // Vendor: delete restaurant
  deleteRestaurant(id: number): Observable<string> {
    return this.http.delete<string>(this.baseUrl + '/vendor/restaurant/' + id, {
      responseType: 'text' as 'json',
    });
  }

  // Vendor: dashboard stats
  getDashboardStats(): Observable<any> {
    return this.http.get<any>(this.baseUrl + '/vendor/stats');
  }

  // Vendor: show vendor orders
  showVendorOrders(venId: number): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/showVendorOrders/' + venId);
  }
}
