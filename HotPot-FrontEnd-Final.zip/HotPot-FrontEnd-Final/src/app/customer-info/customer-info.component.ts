import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-info',
  standalone: true,
  imports: [FormsModule,CommonModule,RouterModule],
  templateUrl: './customer-info.component.html',
  styleUrl: './customer-info.component.css'
})
export class CustomerInfoComponent {
  customer: Customer;
  constructor(private _customerService : CustomerService) {
    const username = localStorage.getItem("username");
    if (username) {
      this._customerService.searchByUsername(username).subscribe(x => {
        this.customer = x;
      });
    }
  }
}
