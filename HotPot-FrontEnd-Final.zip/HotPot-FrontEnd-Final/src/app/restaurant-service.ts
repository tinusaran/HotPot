import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Restaurant } from './restaurant';

@Injectable({ providedIn: 'root' })
export class RestaurantService {
  private baseUrl = 'http://localhost:9090';

  constructor(private http: HttpClient) {}

  // Add new restaurant
  addRestaurant(restaurant: Restaurant): Observable<string> {
    return this.http.post(this.baseUrl + '/addRestaurant', restaurant, {
      responseType: 'text',
    });
  }

  // Fetch all restaurants
  showAllRestaurants(): Observable<Restaurant[]> {
    return this.http.get<Restaurant[]>(this.baseUrl + '/showRestaurants');
  }

  // Fetch restaurant by city
  getRestaurantByCity(city: string): Observable<Restaurant[]> {
    return this.http.get<Restaurant[]>(
      this.baseUrl + '/searchRestaurantByCity/' + city
    );
  }

  // Fetch by ID
  getRestaurantById(id: number): Observable<Restaurant> {
    return this.http.get<Restaurant>(this.baseUrl + '/searchRestaurantById/' + id);
  }

  // Delete restaurant
  deleteRestaurant(id: number): Observable<string> {
    return this.http.delete(this.baseUrl + '/deleteRestaurant/' + id, {
      responseType: 'text',
    });
  }

  // Fetch restaurant info by name and location
  getByNameAndLocation(name: string, location: string): Observable<Restaurant> {
    return this.http.get<Restaurant>(
      this.baseUrl + '/searchRestaurantByNameAndLocation/' + name + '/' + location
    );
  }

  // Fetch restaurant info by username (new correct endpoint)
  getByUsername(username: string): Observable<Restaurant> {
    return this.http.get<Restaurant>(
      this.baseUrl + '/searchRestaurantByUsername/' + username
    );
  }
}
