import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerService } from '../customer.service';
import { Customer } from '../customer';

@Component({
  selector: 'app-view-customers',
  standalone: true,
  imports: [CommonModule],
  template: `
    <h2>All Customers</h2>
    <table border="1" cellpadding="8">
      <tr>
        <th>ID</th><th>Name</th><th>Username</th><th>Email</th><th>Phone</th>
      </tr>
      <tr *ngFor="let c of customers">
        <td>{{ c.cusId }}</td>
        <td>{{ c.cusName }}</td>
        <td>{{ c.cusUsername }}</td>
        <td>{{ c.cusEmail }}</td>
        <td>{{ c.cusPhnNo }}</td>
      </tr>
    </table>
  `,
})
export class ViewCustomersComponent implements OnInit {
  customers: Customer[] = [];
  constructor(private customerService: CustomerService) {}
  ngOnInit() {
    this.customerService.getAllCustomers().subscribe((data) => (this.customers = data));
  }
} 