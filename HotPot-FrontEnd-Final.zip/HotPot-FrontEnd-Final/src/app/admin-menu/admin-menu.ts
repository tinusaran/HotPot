import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-menu',
  standalone: true,
  templateUrl: './admin-menu.html',
  styleUrls: ['./admin-menu.css']
})
export class AdminMenuComponent {} 