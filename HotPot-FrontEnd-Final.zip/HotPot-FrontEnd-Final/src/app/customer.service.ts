import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer';
import { AuthRequestModel } from './auth-request.model';

@Injectable({ providedIn: 'root' })
export class CustomerService {
  private baseUrl = 'http://localhost:9090';

  constructor(private http: HttpClient) {}

  // Register a new customer
  registerCustomer(customer: Customer): Observable<string> {
    return this.http.post(this.baseUrl + '/addCustomer', customer, {
      responseType: 'text',
    });
  }

  // Login customer (returns AuthResponse)
  loginCustomer(request: AuthRequestModel): Observable<any> {
    return this.http.post<any>(
      this.baseUrl + '/auth/login',
      {
        username: request.username,
        password: request.password,
      }
    );
  }

  // Get all customers
  getAllCustomers(): Observable<Customer[]> {
    return this.http.get<Customer[]>(this.baseUrl + '/showCustomers');
  }

  // Search customer by username
  searchByUsername(username: string): Observable<Customer> {
    return this.http.get<Customer>(
      this.baseUrl + '/searchCustomerByUsername/' + username
    );
  }
}
