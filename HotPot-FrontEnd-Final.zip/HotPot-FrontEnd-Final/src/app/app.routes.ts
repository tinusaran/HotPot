import { Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';

import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { CustomerMenuComponent } from './customer-menu/customer-menu.component';
import { CustomerInfoComponent } from './customer-info/customer-info.component';
import { CustomerWalletsComponent } from './customer-wallets/customer-wallets.component';
import { CustomerOrdersComponent } from './customer-orders/customer-orders.component';
import { CustomerPendingOrdersComponent } from './customer-pending-orders/customer-pending-orders.component';
import { PlaceOrderComponent } from './place-order/place-order.component';

import { AdminLoginComponent } from './admin-login/admin-login';
import { AdminMenuComponent as VendorAdminMenuComponent } from './vendor-menu/admin-menu';
import { AdminInfoComponent } from './admin-info/admin-info';
import { AdminOrdersComponent } from './admin-orders/admin-orders';
import { AdminPendingOrdersComponent } from './admin-pending-orders/admin-pending-orders';
import { AdminAcceptRejectComponent } from './admin-accept-reject/admin-accept-reject';

import { RestaurantLoginComponent } from './restaurant-login/restaurant-login';
import { RestaurantMenuComponent } from './restaurant-menu/restaurant-menu';
import { RestaurantInfoComponent } from './restaurant-info/restaurant-info';
import { AddMenuComponent } from './add-menu/add-menu';
import { ViewOrdersComponent } from './view-orders/view-orders';
import { CartComponent } from './cart/cart';
import { AddVendorComponent } from './add-vendor/add-vendor';
import { ViewRestaurantsComponent } from './view-restaurants/view-restaurants';
import { ViewCustomersComponent } from './view-customers/view-customers';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },

  { path: 'customerLogin', component: CustomerLoginComponent },
  {
    path: 'customerMenu',
    component: CustomerMenuComponent,
    children: [
      {
        path: 'customerInfo',
        component: CustomerInfoComponent,
        outlet: 'customer',
      },
      {
        path: 'customerWallet',
        component: CustomerWalletsComponent,
        outlet: 'customer',
      },
      {
        path: 'customerOrders',
        component: CustomerOrdersComponent,
        outlet: 'customer',
      },
      { path: 'cart', component: CartComponent, outlet: 'customer' },
      {
        path: 'customerPendingOrders',
        component: CustomerPendingOrdersComponent,
        outlet: 'customer',
      },
      {
        path: 'placeOrder',
        component: PlaceOrderComponent,
        outlet: 'customer',
      },
    ],
  },

  { path: 'adminLogin', component: AdminLoginComponent },
  {
    path: 'adminMenu',
    component: VendorAdminMenuComponent,
    children: [
      { path: 'adminInfo', component: AdminInfoComponent, outlet: 'admin' },
      { path: 'adminOrders', component: AdminOrdersComponent, outlet: 'admin' },
      { path: 'addVendor', component: AddVendorComponent, outlet: 'admin' },
      { path: 'viewRestaurants', component: ViewRestaurantsComponent, outlet: 'admin' },
      { path: 'viewCustomers', component: ViewCustomersComponent, outlet: 'admin' },
    ],
  },

  // ✅ Restaurant routes at root level
  { path: 'restaurantLogin', component: RestaurantLoginComponent },
  {
    path: 'restaurantMenu',
    component: RestaurantMenuComponent,
    children: [
      {
        path: 'restaurantInfo',
        component: RestaurantInfoComponent,
        outlet: 'restaurant',
      },
      {
        path: 'addMenu',
        component: AddMenuComponent,
        outlet: 'restaurant',
      },
      {
        path: 'viewOrders',
        component: ViewOrdersComponent,
        outlet: 'restaurant',
      },
    ],
  },
];
