export class Restaurant {
  resId: number;
  resName: string;
  resLocation: string;
  resUsername: string;
  resPassword: string;
  role: string;
  constructor() {}
}
