import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { Menu } from '../menu';
import { CartService } from '../cart-service';
import { MenuService } from '../menu.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './cart.html',
  styleUrls: ['./cart.css'],
})
export class CartComponent {
  customerId: number = parseInt(localStorage.getItem('cid') || '0');
  menuList: Menu[] = [];
  cartList: any[] = [];
  result: string = '';

  cart = {
    menuId: '',
    quantityOrdered: 1,
  };

  constructor(
    private cartService: CartService,
    private menuService: MenuService
  ) {
    this.loadCart();
    this.menuService.showMenu().subscribe((data) => (this.menuList = data));
  }

  getToken(): string {
    return localStorage.getItem('token') || '';
  }

  loadCart() {
    this.cartService.viewCart(this.getToken()).subscribe((data) => {
      this.cartList = data.map(item => ({
        cartId: item.cartId,
        menuId: item.menu?.menuId || item.menu?.menId || item.menuId,
        quantity: item.quantity
      }));
    });
  }

  addToCart(): void {
    if (this.cart.menuId && this.cart.quantityOrdered > 0) {
      this.cartService.addToCart(this.getToken(), +this.cart.menuId, this.cart.quantityOrdered).subscribe({
        next: () => {
          this.result = 'Item added to cart!';
          this.loadCart(); // reload
        },
        error: (err) => {
          console.error('Error adding to cart:', err);
          this.result = 'Failed to add to cart.';
        },
      });
    }
  }

  removeFromCart(cartId: number): void {
    // Find the menuId for this cartId
    const cartItem = this.cartList.find(c => c.cartId === cartId);
    if (cartItem) {
      this.cartService.removeFromCart(this.getToken(), cartItem.menuId).subscribe(() => {
        alert('Item removed from cart');
        this.loadCart();
      });
    }
  }

  clearCart(): void {
    this.cartService.clearCart(this.getToken()).subscribe(() => {
      alert('Cart cleared');
      this.loadCart();
    });
  }
}
