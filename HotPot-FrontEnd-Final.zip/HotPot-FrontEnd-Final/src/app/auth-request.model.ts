export class AuthRequestModel {
  username: string = '';
  password: string = '';
}
