import { Component } from '@angular/core';
import { MenuService } from '../menu.service';
import { Menu } from '../menu';
import { Restaurant } from '../restaurant';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-add-menu',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './add-menu.html',
  styleUrls: ['./add-menu.css'],
})
export class AddMenuComponent {
  menu: Menu = new Menu();
  result: string = '';
  categories: string[] = [
    'Breakfast',
    'Lunch',
    'Dinner',
    'Starter',
    'Snack',
    'Main Course',
  ];

  constructor(private menuService: MenuService) {}

  add(): void {
    const resId = localStorage.getItem('resId');
    if (resId) {
      this.menu.restaurant = new Restaurant();
      this.menu.restaurant.resId = +resId;
      this.menu.menuCalories = this.menu.menuCalories || 0;
      this.menuService.addMenuToRestaurant(this.menu, +resId).subscribe({
        next: (res) => (this.result = res),
        error: (err) => {
          console.error('Failed to add menu:', err);
          this.result = 'Failed to add menu';
        },
      });
    }
  }
}
