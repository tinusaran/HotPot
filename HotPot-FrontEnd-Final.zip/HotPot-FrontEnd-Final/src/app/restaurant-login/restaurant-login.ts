import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Restaurant } from '../restaurant';
import { RestaurantService } from '../restaurant-service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-restaurant-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './restaurant-login.html',
  styleUrl: './restaurant-login.css',
})
export class RestaurantLoginComponent {
  restaurant: Restaurant = new Restaurant();
  message: string = '';
  isValid: boolean = false;

  constructor(
    private restaurantService: RestaurantService,
    private http: HttpClient,
    private router: Router
  ) {}

  login(loginForm: NgForm): void {
    this.isValid = false;
    if (loginForm.invalid) return;

    this.isValid = true;

    // Use /auth/login endpoint directly
    this.http
      .post<any>('http://localhost:9090/auth/login', {
        username: this.restaurant.resUsername,
        password: this.restaurant.resPassword,
      })
      .subscribe({
        next: (res: any) => {
          if (res && res.token) {
            localStorage.setItem('token', res.token);
            localStorage.setItem('role', res.role);
            // Fetch restaurant info by username
            this.restaurantService
              .getByUsername(this.restaurant.resUsername)
              .subscribe((restList) => {
                const rest = Array.isArray(restList) ? restList[0] : restList;
                localStorage.setItem('resId', rest.resId?.toString() || '');
                localStorage.setItem('resName', rest.resName || '');
                this.router.navigate(['restaurantMenu']);
              });
          } else {
            this.message = 'Invalid credentials.';
          }
        },
        error: (err: any) => {
          console.error('Login failed', err);
          this.message = 'Invalid credentials or error during login.';
        },
      });
  }
}
