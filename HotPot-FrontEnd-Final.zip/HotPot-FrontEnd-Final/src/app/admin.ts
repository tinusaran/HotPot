export class Admin {
  venId: number; // ven_id
  venName: string; // ven_name
  venEmail: string; // ven_email
  venUsername: string; // ven_username
  venPassword: string; // ven_password
  venPhnNo: string; // ven_phn_no
  role: string;
  constructor() {}
} 