import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { Orders } from '../orders';
import { OrdersService } from '../orders.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-customer-orders',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './customer-orders.component.html',
  styleUrl: './customer-orders.component.css',
})
export class CustomerOrdersComponent implements OnInit, OnDestroy {
  customerOrders: Orders[] = [];
  cid: number;
  private orderUpdateSub: Subscription;
  constructor(private _orderService: OrdersService) {
    this.cid = parseInt(localStorage.getItem('cid'));
  }

  ngOnInit() {
    this.fetchOrders();
    this.orderUpdateSub = this._orderService.orderUpdated$.subscribe(() => {
      this.fetchOrders();
    });
  }

  fetchOrders() {
    this._orderService.getOrdersByCustomer(this.cid).subscribe((x) => {
      this.customerOrders = x;
    });
  }

  ngOnDestroy() {
    if (this.orderUpdateSub) {
      this.orderUpdateSub.unsubscribe();
    }
  }
}
