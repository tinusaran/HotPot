import { Restaurant } from './restaurant';

export class Menu {
  menuId: number; // MEN_ID
  menuCalories: number;
  itemName: string; // menu_item
  price: number; // menu_price
  menuSpeciality: string; // menu_speciality
  restaurant: Restaurant; // restaurant_id
  description?: string;
  category?: string;
  availabilityTime?: string;
  dietaryInfo?: string;
  tasteInfo?: string;
  nutritionInfo?: string;
  constructor() {}
}
