import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class CartService {
  private baseUrl = 'http://localhost:9090/cart';

  constructor(private http: HttpClient) {}

  // Add to cart (requires Authorization header)
  addToCart(token: string, menuId: number, quantity: number): Observable<string> {
    const headers = new HttpHeaders({ Authorization: token });
    return this.http.post<string>(
      `${this.baseUrl}/add?menuId=${menuId}&quantity=${quantity}`,
      {},
      { headers, responseType: 'text' as 'json' }
    );
  }

  // View cart (requires Authorization header)
  viewCart(token: string): Observable<any[]> {
    const headers = new HttpHeaders({ Authorization: token });
    return this.http.get<any[]>(`${this.baseUrl}/view`, { headers });
  }

  // Update quantity (requires Authorization header)
  updateQuantity(token: string, menuId: number, quantity: number): Observable<string> {
    const headers = new HttpHeaders({ Authorization: token });
    return this.http.put<string>(
      `${this.baseUrl}/update?menuId=${menuId}&quantity=${quantity}`,
      {},
      { headers, responseType: 'text' as 'json' }
    );
  }

  // Remove an item (requires Authorization header)
  removeFromCart(token: string, menuId: number): Observable<string> {
    const headers = new HttpHeaders({ Authorization: token });
    return this.http.delete<string>(
      `${this.baseUrl}/remove?menuId=${menuId}`,
      { headers, responseType: 'text' as 'json' }
    );
  }

  // Clear entire cart (requires Authorization header)
  clearCart(token: string): Observable<string> {
    const headers = new HttpHeaders({ Authorization: token });
    return this.http.delete<string>(
      `${this.baseUrl}/clear`,
      { headers, responseType: 'text' as 'json' }
    );
  }
}
