export class Vendor {
  venId: number;
  venName: string;
  venPhnNo: string;
  venUsername: string;
  venPassword: string;
  venEmail: string;
  role: string = 'vendor';
  constructor() {}
}
