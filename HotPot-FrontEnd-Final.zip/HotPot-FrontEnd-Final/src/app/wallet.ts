export class Wallet {
  walId: number;
  cusId: number;
  walAmount: number;
  walSource: string;
  constructor() {}
}
