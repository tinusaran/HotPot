import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Orders } from './orders';
import { Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class OrdersService {
  private baseUrl = 'http://localhost:9090';

  // Subject to notify order updates
  private orderUpdatedSource = new Subject<void>();
  orderUpdated$ = this.orderUpdatedSource.asObservable();

  constructor(private http: HttpClient) {}

  // Place order (direct)
  placeOrder(order: Orders): Observable<string> {
    return this.http.post(this.baseUrl + '/placeOrder', order, {
      responseType: 'text',
    });
  }

  // Place order from cart
  placeOrderFromCart(username: string, wallet: string, comments?: string): Observable<string> {
    let params = `?username=${username}&wallet=${wallet}`;
    if (comments) params += `&comments=${encodeURIComponent(comments)}`;
    return this.http.post(this.baseUrl + '/placeOrderFromCart' + params, {}, {
      responseType: 'text',
    });
  }

  // Get orders by customer
  getOrdersByCustomer(custId: number): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/ordersByCustomer/' + custId);
  }

  // Get orders by vendor
  getOrdersByVendor(venId: number): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/ordersByVendor/' + venId);
  }

  // Get all vendor orders (admin view)
  getAllVendorOrders(): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/vendor/orders');
  }

  // Accept or reject order (vendor)
  updateOrderStatus(vendorId: number, orderId: number, status: string): Observable<string> {
    return this.http.post(
      `${this.baseUrl}/acceptOrReject/${vendorId}/${orderId}/${status}`,
      {},
      { responseType: 'text' }
    );
  }

  // Call this after updating an order
  notifyOrderUpdated() {
    this.orderUpdatedSource.next();
  }

  // Get orders by restaurant
  getOrdersByRestaurant(resId: number): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/ordersByRestaurant/' + resId);
  }
}
