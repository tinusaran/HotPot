import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Admin } from './admin';
import { Orders } from './orders';
import { Menu } from './menu';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  private baseUrl = 'http://localhost:9090';

  constructor(private http: HttpClient) {}

  // Login as admin (vendor)
  loginAdmin(admin: Admin): Observable<any> {
    return this.http.post<any>(
      this.baseUrl + '/auth/login',
      {
        username: admin.venUsername,
        password: admin.venPassword,
      }
    );
  }

  // Add admin (vendor)
  addAdmin(admin: Admin): Observable<string> {
    return this.http.post<string>(this.baseUrl + '/addVendor', admin, {
      responseType: 'text' as 'json',
    });
  }

  // Get all admins (vendors)
  getAllAdmins(): Observable<Admin[]> {
    return this.http.get<Admin[]>(this.baseUrl + '/showVendors');
  }

  // Get admin (vendor) by username
  getAdminByUsername(username: string): Observable<Admin> {
    return this.http.get<Admin>(this.baseUrl + '/searchVendorByUsername/' + username);
  }

  // Get admin (vendor) by ID
  getAdminById(venId: number): Observable<Admin> {
    return this.http.get<Admin>(this.baseUrl + '/searchVendorById/' + venId);
  }

  // Admin (vendor): get all customers
  getAllCustomers(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl + '/vendor/customers');
  }

  // Admin (vendor): get all restaurants
  getAllRestaurants(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl + '/vendor/restaurants');
  }

  // Admin (vendor): get all orders
  getAllOrders(): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/vendor/orders');
  }

  // Admin (vendor): delete customer
  deleteCustomer(id: number): Observable<string> {
    return this.http.delete<string>(this.baseUrl + '/vendor/customer/' + id, {
      responseType: 'text' as 'json',
    });
  }

  // Admin (vendor): delete restaurant
  deleteRestaurant(id: number): Observable<string> {
    return this.http.delete<string>(this.baseUrl + '/vendor/restaurant/' + id, {
      responseType: 'text' as 'json',
    });
  }

  // Admin (vendor): dashboard stats
  getDashboardStats(): Observable<any> {
    return this.http.get<any>(this.baseUrl + '/vendor/stats');
  }

  // Admin (vendor): show vendor orders
  showVendorOrders(venId: number): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/showVendorOrders/' + venId);
  }
} 