export class Customer {
  cusId: number; // CUS_ID
  role: string;
  cusEmail: string;
  cusName: string;
  cusPassword: string;
  cusPhnNo: string;
  cusUsername: string;
  constructor() {}
}
