import { Component, OnInit } from '@angular/core';
import { OrdersService } from '../orders.service';
import { Orders } from '../orders';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-view-orders',
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './view-orders.html',
  styleUrl: './view-orders.css',
})
export class ViewOrdersComponent implements OnInit {
  orders: Orders[] = [];

  constructor(private orderService: OrdersService) {}

  ngOnInit(): void {
    const resId = localStorage.getItem('resId');
    if (resId) {
      this.orderService
        .getOrdersByRestaurant(+resId)
        .subscribe((data) => (this.orders = data));
    }
  }

  updateStatus(orderId: number, status: string): void {
    // Find the order object by orderId
    const order = this.orders.find(o => o.orderId === orderId);
    if (!order) return;

    const venId = order.venId; // Use the vendor ID from the order
    const resId = order.resId; // Use the restaurant ID from the order
    this.orderService
      .updateOrderStatus(venId, orderId, status)
      .subscribe(() => {
        alert(`Order ${status.charAt(0) + status.slice(1).toLowerCase()}!`);
        this.orderService.getOrdersByRestaurant(resId).subscribe((data) => {
          this.orders = data;
          console.log('Updated orders:', this.orders);
        });
        this.orderService.notifyOrderUpdated();
      });
  }
}
