import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Menu } from './menu';

@Injectable({
  providedIn: 'root',
})
export class MenuService {
  private baseUrl = 'http://localhost:9090';

  constructor(private _http: HttpClient) {}

  // Add Menu by Restaurant
  addMenuToRestaurant(menu: Menu, restaurantId: number): Observable<string> {
    return this._http.post<string>(
      `${this.baseUrl}/restaurant/${restaurantId}/addMenu`,
      menu,
      { responseType: 'text' as 'json' }
    );
  }

  // Add Menu by Vendor
  addMenuByVendor(menuDto: any, restaurantId: number): Observable<string> {
    return this._http.post<string>(
      `${this.baseUrl}/vendor/menu/add/${restaurantId}`,
      menuDto,
      { responseType: 'text' as 'json' }
    );
  }

  // Update Menu by Vendor
  updateMenuByVendor(menuId: number, menuDto: any): Observable<string> {
    return this._http.put<string>(
      `${this.baseUrl}/vendor/menu/update/${menuId}`,
      menuDto,
      { responseType: 'text' as 'json' }
    );
  }

  // Show all menu
  showMenu(): Observable<Menu[]> {
    return this._http.get<Menu[]>(`${this.baseUrl}/showMenu`);
  }

  // Search menu by ID
  searchById(id: number): Observable<Menu> {
    return this._http.get<Menu>(`${this.baseUrl}/searchMenuById/${id}`);
  }

  // Search menu by restaurant ID
  searchByRestaurantId(restaurantId: number): Observable<Menu[]> {
    return this._http.get<Menu[]>(
      `${this.baseUrl}/searchMenuByRestaurant/${restaurantId}`
    );
  }

  // Search menu by speciality
  searchBySpeciality(type: string): Observable<Menu[]> {
    return this._http.get<Menu[]>(`${this.baseUrl}/searchMenuBySpeciality/${type}`);
  }

  // Delete menu by Vendor
  deleteMenuByVendor(menuId: number): Observable<string> {
    return this._http.delete<string>(`${this.baseUrl}/vendor/menu/delete/${menuId}`, {
      responseType: 'text' as 'json',
    });
  }
}
