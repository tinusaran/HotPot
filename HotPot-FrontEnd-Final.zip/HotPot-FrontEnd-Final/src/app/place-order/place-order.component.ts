import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { Menu } from '../menu';
import { Admin } from '../admin';
import { Orders } from '../orders';
import { Wallet } from '../wallet';

import { MenuService } from '../menu.service';
import { AdminService } from '../admin-service';
import { WalletService } from '../wallet.service';
import { OrdersService } from '../orders.service';

@Component({
  selector: 'app-place-order',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './place-order.component.html',
  styleUrl: './place-order.component.css',
})
export class PlaceOrderComponent {
  menu: Menu[] = [];
  admin: Admin[] = [];
  orders: Orders = new Orders();
  wallet: Wallet[] = [];
  result: any;

  constructor(
    private _menuService: MenuService,
    private _adminService: AdminService,
    private _walletService: WalletService,
    private _orderService: OrdersService
  ) {
    this.orders.custId = parseInt(localStorage.getItem('cid') || '0');

    this._menuService.showMenu().subscribe((x) => {
      this.menu = x;
    });

    this._adminService.getAllAdmins().subscribe((x) => {
      this.admin = x;
    });

    this._walletService.getWalletsByCustomer(this.orders.custId).subscribe((x) => {
      this.wallet = x;
    });
  }

  onMenuSelect() {
    const selected = this.menu.find((m) => m.menuId === +this.orders.menuId);
    // If you need to use restaurant info, you can access selected.restaurant
  }

  placeOrder(orderForm: NgForm) {
    if (orderForm.invalid) return;

    // Calculate bill amount if needed
    const selected = this.menu.find((m) => m.menuId === +this.orders.menuId);
    if (selected) {
      this.orders.billAmount = selected.price * +this.orders.quantityOrdered;
    }

    // Coerce all IDs and numeric fields
    this.orders.menuId = +this.orders.menuId;
    this.orders.venId = +this.orders.venId;
    this.orders.quantityOrdered = +this.orders.quantityOrdered;

    console.log('Order Payload: ', this.orders);

    this._orderService.placeOrder(this.orders).subscribe({
      next: (res: any) => {
        this.result =
          typeof res === 'string'
            ? res
            : res?.message ?? 'Order placed successfully';
        alert(this.result);
      },
      error: (err) => {
        console.error('Order failed', err);
        alert('Something went wrong while placing the order.');
      },
    });
  }
}
