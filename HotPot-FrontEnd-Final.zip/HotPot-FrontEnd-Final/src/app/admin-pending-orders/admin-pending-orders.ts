import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Orders } from '../orders';
import { AdminService } from '../admin-service';

@Component({
  selector: 'app-admin-pending-orders',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin-pending-orders.html',
  styleUrls: ['./admin-pending-orders.css'],
})
export class AdminPendingOrdersComponent {
  venId: number = parseInt(localStorage.getItem('venId') || '0');
  orders: Orders[] = [];

  constructor(private _adminService: AdminService) {
    if (!this.venId || isNaN(this.venId)) {
      console.error('Vendor ID is invalid or missing in localStorage.');
      return;
    }
    this._adminService
      .showVendorOrders(this.venId)
      .subscribe((data: Orders[]) => {
        this.orders = data.filter(
          (o) => o.orderStatus?.toUpperCase() === 'PENDING'
        );
      });
  }
}
