export class Orders {
  orderId: number; // order_id
  custId: number;
  venId: number;
  menuId: number;
  walSource: string;
  quantityOrdered: number;
  billAmount: number;
  orderStatus: string;
  comments: string;
  resId?: number;
  constructor() {}
}
