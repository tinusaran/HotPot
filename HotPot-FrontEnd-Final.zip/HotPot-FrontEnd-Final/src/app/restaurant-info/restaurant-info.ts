import { Component, OnInit } from '@angular/core';

import { Restaurant } from '../restaurant';
import { RestaurantService } from '../restaurant-service';

@Component({
  selector: 'app-restaurant-info',
  templateUrl: './restaurant-info.html',
  styleUrl: './restaurant-info.css',
})
export class RestaurantInfoComponent implements OnInit {
  restaurant: Restaurant = new Restaurant();

  constructor(private service: RestaurantService) {}

  ngOnInit(): void {
    const resId = localStorage.getItem('resId');
    if (resId) {
      this.service
        .getRestaurantById(+resId)
        .subscribe((data) => (this.restaurant = data));
    }
  }
}
