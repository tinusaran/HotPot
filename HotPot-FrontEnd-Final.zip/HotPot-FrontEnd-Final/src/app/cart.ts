export class Cart {
  cartId?: number;
  customer: { cusId: number } = { cusId: 0 };
  menu: { menId: number } = { menId: 0 };
  quantity: number = 1;
}
