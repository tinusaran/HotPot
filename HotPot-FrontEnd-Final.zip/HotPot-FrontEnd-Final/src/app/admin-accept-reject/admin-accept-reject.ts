import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Orders } from '../orders';
import { AdminService } from '../admin-service';
import { OrdersService } from '../orders.service';

@Component({
  selector: 'app-admin-accept-reject',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin-accept-reject.html',
  styleUrls: ['./admin-accept-reject.css'],
})
export class AdminAcceptRejectComponent {
  venId: number = parseInt(localStorage.getItem('venId') || '0');
  orders: Orders[] = [];
  result: string = '';
  comments: string = '';

  constructor(private _adminService: AdminService, private _orderService: OrdersService) {
    if (!this.venId || isNaN(this.venId)) {
      console.error('Vendor ID is invalid or missing in localStorage.');
      return;
    }
    this.refreshOrders();
  }

  yes(orderId: number): void {
    this._orderService
      .updateOrderStatus(this.venId, orderId, 'ACCEPTED')
      .subscribe(() => {
        alert('Order accepted.');
        this.refreshOrders();
      });
  }

  no(orderId: number): void {
    this._orderService
      .updateOrderStatus(this.venId, orderId, 'DENIED')
      .subscribe(() => {
        alert('Order denied.');
        this.refreshOrders();
      });
  }

  refreshOrders(): void {
    this._adminService.showVendorOrders(this.venId).subscribe((data) => {
      this.orders = data.filter((o) => o.orderStatus?.toUpperCase() === 'PENDING');
    });
  }
}
