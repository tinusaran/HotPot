import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminAcceptRejectComponent } from './admin-accept-reject';

describe('AdminAcceptReject', () => {
  let component: AdminAcceptRejectComponent;
  let fixture: ComponentFixture<AdminAcceptRejectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminAcceptRejectComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AdminAcceptRejectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
