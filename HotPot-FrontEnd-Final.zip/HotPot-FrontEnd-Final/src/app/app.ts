import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { CustomerMenuComponent } from './customer-menu/customer-menu.component';
import { CustomerInfoComponent } from './customer-info/customer-info.component';
import { CustomerOrdersComponent } from './customer-orders/customer-orders.component';
import { CustomerPendingOrdersComponent } from './customer-pending-orders/customer-pending-orders.component';
import { CustomerWalletsComponent } from './customer-wallets/customer-wallets.component';
import { AdminAcceptRejectComponent } from './admin-accept-reject/admin-accept-reject';
import { AdminInfoComponent } from './admin-info/admin-info';
import { AdminLoginComponent } from './admin-login/admin-login';
import { AdminMenuComponent } from './admin-menu/admin-menu';
import { AdminOrdersComponent } from './admin-orders/admin-orders';
import { AdminPendingOrdersComponent } from './admin-pending-orders/admin-pending-orders';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AddVendorComponent } from './add-vendor/add-vendor';
import { ViewRestaurantsComponent } from './view-restaurants/view-restaurants';
import { ViewCustomersComponent } from './view-customers/view-customers';

@Component({
  selector: 'app-root',
  imports: [
    RouterOutlet,
    CustomerLoginComponent,
    CustomerMenuComponent,
    CustomerInfoComponent,
    CustomerOrdersComponent,
    CustomerPendingOrdersComponent,
    CustomerWalletsComponent,
    FormsModule,
    AddVendorComponent,
    ViewRestaurantsComponent,
    ViewCustomersComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  protected title = 'HotPot';
}
