import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Wallet } from './wallet';

@Injectable({ providedIn: 'root' })
export class WalletService {
  private baseUrl = 'http://localhost:9090';

  constructor(private http: HttpClient) {}

  // Get all wallets
  showAllWallets(): Observable<Wallet[]> {
    return this.http.get<Wallet[]>(`${this.baseUrl}/showWallets`);
  }

  // Add wallet
  addWallet(wallet: Wallet): Observable<string> {
    return this.http.post(this.baseUrl + '/addWallet', wallet, {
      responseType: 'text',
    });
  }

  // Get wallets by customer
  getWalletsByCustomer(cusId: number): Observable<Wallet[]> {
    return this.http.get<Wallet[]>(`${this.baseUrl}/getCustomerWallets/${cusId}`);
  }

  // Top up wallet
  topUp(wallet: Wallet): Observable<Wallet> {
    return this.http.post<Wallet>(`${this.baseUrl}/topUp`, wallet);
  }

  // Deduct from wallet
  deduct(wallet: Wallet): Observable<string> {
    return this.http.post<string>(`${this.baseUrl}/deduct`, wallet, {
      responseType: 'text' as 'json',
    });
  }
}
