import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RestaurantService } from '../restaurant-service';
import { Restaurant } from '../restaurant';

@Component({
  selector: 'app-view-restaurants',
  standalone: true,
  imports: [CommonModule],
  template: `
    <h2>All Restaurants</h2>
    <table border="1" cellpadding="8">
      <tr>
        <th>ID</th><th>Name</th><th>Location</th><th>Username</th>
      </tr>
      <tr *ngFor="let r of restaurants">
        <td>{{ r.resId }}</td>
        <td>{{ r.resName }}</td>
        <td>{{ r.resLocation }}</td>
        <td>{{ r.resUsername }}</td>
      </tr>
    </table>
  `,
})
export class ViewRestaurantsComponent implements OnInit {
  restaurants: Restaurant[] = [];
  constructor(private restaurantService: RestaurantService) {}
  ngOnInit() {
    this.restaurantService.showAllRestaurants().subscribe((data) => (this.restaurants = data));
  }
} 