import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { AdminService } from '../admin-service';
import { Admin } from '../admin';

@Component({
  selector: 'app-add-vendor',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <h2>Add Vendor</h2>
    <form #vendorForm="ngForm" (ngSubmit)="addVendor(vendorForm)">
      <label>Username: <input [(ngModel)]="vendor.venUsername" name="venUsername" required /></label><br />
      <label>Password: <input [(ngModel)]="vendor.venPassword" name="venPassword" required type="password" /></label><br />
      <label>Name: <input [(ngModel)]="vendor.venName" name="venName" required /></label><br />
      <label>Email: <input [(ngModel)]="vendor.venEmail" name="venEmail" required type="email" /></label><br />
      <label>Phone: <input [(ngModel)]="vendor.venPhnNo" name="venPhnNo" required /></label><br />
      <button type="submit">Add Vendor</button>
    </form>
    <p style="color: green">{{ result }}</p>
  `,
})
export class AddVendorComponent {
  vendor: Admin = new Admin();
  result: string = '';
  constructor(private adminService: AdminService) {}
  addVendor(form: NgForm) {
    if (form.invalid) return;
    this.adminService.addAdmin(this.vendor).subscribe({
      next: (res) => (this.result = 'Vendor added successfully!'),
      error: (err) => (this.result = 'Failed to add vendor'),
    });
  }
} 